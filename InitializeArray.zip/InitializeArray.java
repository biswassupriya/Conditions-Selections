import java.util.Scanner;

public class InitializeArray {

    public static void main(String[] args) {
        int[] arrayNumber = new int[6];
        Scanner sc = new Scanner(System.in);
/*
        do {

            System.out.println("No of Elements in array: "  +  array.length);
            System.out.println(" Enter an Array");
            sc.nextInt();
            System.out.println(" Enter an Array ");
            sc.nextInt();
            System.out.println("Enter an Array ");
            sc.nextInt();
            System.out.println("Enter an Array ");
            sc.nextInt();
            System.out.println("Enter an Array ");
            sc.nextInt();
            System.out.println("Enter an Array ");
            sc.nextInt();
            System.out.println("Enter an Array ");
            sc.nextInt();
            System.out.println("Enter an Array");
            sc.nextInt();
            System.out.println("Enter an Array");
            sc.nextInt();
            System.out.println("Enter an Array ");
            sc.nextInt();
            System.out.println("Enter an Array ");
            sc.nextInt();
            System.out.println("Enter an Array ");
            sc.nextInt();
            System.out.println("Enter an Array ");
            sc.nextInt();
            System.out.println("Enter an Array ");
            sc.nextInt();
            System.out.println("Enter an Array");
            sc.nextInt();

        } while (array.length == 15);
        System.out.println("Sorry data are full");*/

        int i = 0;
        do {
            System.out.println("Enter an number ");
            final var number = sc.nextInt();
            arrayNumber[i] = number;
            ++i;
        } while (arrayNumber.length - 1 >= i);

        int j = 0;
        while (j < 3) {
            System.out.println(j + " Element in Array [" + arrayNumber[j] + "]");
            j++;
        }


       /* int i;
        for(i = 0 ; i < 10 ; i++){
            System.out.println(i);
            continue;
        }*/
    }
}
