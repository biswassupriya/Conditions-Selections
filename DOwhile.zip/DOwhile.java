import java.sql.SQLOutput;
import java.util.Scanner;

public class DOwhile {

    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
/*        int number = 0 ;
        String number1 = "";

        do{
            System.out.println("Enter number:");
            number = sc.nextInt();
            if(number > 0){
                number++;
                System.out.println(number++);
                number = sc.nextInt();

            }
        }
        while (number1 == "X");
        number1 = sc.next();
        System.out.println("Enter X");
        number1 = sc.next();
        System.out.println("Outside the loop");*/

        String next = null;


        do {
            final boolean isInteger = sc.hasNextInt();
            if (!isInteger) {
                next = sc.next();
            } else {
                final var number = sc.nextInt();
                System.out.println("number " + number);
            }
            System.out.println("isInteger " + isInteger);
            System.out.println("next " + next);
        } while (!"x".equalsIgnoreCase(next));
    }
}